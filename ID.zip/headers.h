
#ifndef HW3__HEADERS_H
#define HW3__HEADERS_H
#include <cstring>
#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <ctime>
#include <algorithm>
#include <list>
#include <exception>
#include "json.hpp"





#endif //HW3__HEADERS_H
